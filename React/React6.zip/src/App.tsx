import { NotificationsPanel } from "./NotificationsPanel"

const App = () => {
  return (
    <>
      <h1>DesignHub</h1>
      <NotificationsPanel />
    </>
  )
}

export default App